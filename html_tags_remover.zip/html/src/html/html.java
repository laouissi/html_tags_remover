
package html;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class html {
	
	//fonction pour convertir un fichier
public static void Nomfichier(String i) {
	
	try {
	      File myObj = new File(i);
	      Scanner myReader = new Scanner(myObj);
	      while (myReader.hasNextLine()) {
	        String data = myReader.nextLine();
	        String str = data;
	        str = str.replaceAll("\\<.*?\\>", "");
	        System.out.println(  str);
	        
	      }
	      myReader.close();
	    } catch (FileNotFoundException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
	  }


  //fonction pour convertir l'URL
public static void URLfichier(String j) {
	
	 try {
         // obtenir l'url
         
         URL url = new URL(j);
         URLConnection conn = url.openConnection();

         // ouvrir le stream et l'entrer dans le BufferedReader
         BufferedReader br = new BufferedReader(
         new InputStreamReader(conn.getInputStream()));
         String inputLine;
         while ((inputLine = br.readLine()) != null) {
        	 
                inputLine = inputLine.replaceAll("\\<.*?\\>", "");
                System.out.println(inputLine);
                  
         }
         
         br.close();

         System.out.println("Done");

     } catch (MalformedURLException e) {
         e.printStackTrace();
     } catch (IOException e) {
         e.printStackTrace();
     }

}

	public static void main(String[] args) {
		Scanner nom = new Scanner(System.in);  // un scanner pour entrer le nom du fichier
		Scanner choix = new Scanner(System.in);  // un scanner pour entrer le nom du fichier
	    System.out.println("si vous voulez convertir un fichier html veuillez entrer le numero 1");
	    System.out.println("si vous voulez convertir un URL veuillez entrer le numero 2");
  
	     int numero;
		do { numero = choix.nextInt();}
        while(numero!= 1 && numero!=2);
	      
	    
	    if(numero == 1) {
		
	    System.out.println("Enter le nom du fichier avec l'extension");

	    String filename = nom.nextLine();  
	    Nomfichier(filename);}
	    
	    else {
	    	
		    System.out.println("Enter le lien du site web");
		    System.out.println("N.B veuillez entrer votre lien sous forme de https://www.exemple.com/");
		    String URL = nom.nextLine();  
		    URLfichier(URL);
	    }
	    }
}
